<?php
// / AKUN CONFIGURASI TTE
define('GATEWAYAPI', 'true'); //true | false
define('HOSTGATEWAY', 'localhost/api_gateway/v1/tte/'); //Ganti dengan key genarate EKLAIM integrasi SIMRS
// ISI LENGKAP JIKA TANPA GATEWAY API 
define('BSREAPI', '10.0.8.80//api/sign/pdf'); //Ganti dengan URL BSSN
define('USERNAMEBSREAPI', ''); //Ganti dengan username BSSN
define('PASSWORDBSREAPI', ''); // Ganti dengan Password BSSN
